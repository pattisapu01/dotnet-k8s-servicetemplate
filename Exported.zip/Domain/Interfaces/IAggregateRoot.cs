namespace Cloud.$ext_safeprojectname$.Domain.Interfaces
{
    public interface IAggregateRoot { }
}
